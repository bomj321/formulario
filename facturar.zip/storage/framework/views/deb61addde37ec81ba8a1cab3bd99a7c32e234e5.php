  <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                          <th><?php echo e($history->mat_edtc); ?></th>
                                          <th><?php echo e($history->description); ?></th>
                                          <th>
                                            <?php 
                                             $historia = DB::table('histories')
                                                   ->select(DB::raw('count(transaction_type_id) as transaction_type_count'))
                                                   ->where('item_id', '=', $history->item_id)
                                                   ->where('transaction_type_id','=', '1')
                                                   ->first(); 

                                              if (!empty($historia->transaction_type_count) AND isset($historia->transaction_type_count))
                                                   {
                                                
                                                     echo $historia->transaction_type_count;

                                                   }else{

                                                     echo '0';

                                                   }
                                            ?>

                                          </th>
                                          <th>
                                             <?php 
                                             $historia = DB::table('histories')
                                                   ->select(DB::raw('count(transaction_type_id) as transaction_type_count'))
                                                   ->where('item_id', '=', $history->item_id)
                                                   ->where('transaction_type_id','=', '2')
                                                   ->first(); 

                                              if (!empty($historia->transaction_type_count) AND isset($historia->transaction_type_count))
                                                   {
                                                
                                                     echo $historia->transaction_type_count;

                                                   }else{

                                                     echo '0';

                                                   }
                                            ?>
                                          </th>

                                           <th>
                                             <?php 
                                             $historia = DB::table('histories')
                                                   ->select(DB::raw('count(transaction_type_id) as transaction_type_count'))
                                                   ->where('item_id', '=', $history->item_id)
                                                   ->where('transaction_type_id','=', '3')
                                                   ->first(); 

                                              if (!empty($historia->transaction_type_count) AND isset($historia->transaction_type_count))
                                                   {
                                                
                                                     echo $historia->transaction_type_count;

                                                   }else{

                                                     echo '0';

                                                   }
                                            ?>
                                          </th>



                                          <th>
                                             <?php 
                                             $historia = DB::table('histories')
                                                   ->select(DB::raw('count(transaction_type_id) as transaction_type_count'))
                                                   ->where('item_id', '=', $history->item_id)
                                                   ->where('transaction_type_id','=', '4')
                                                   ->first(); 

                                              if (!empty($historia->transaction_type_count) AND isset($historia->transaction_type_count))
                                                   {
                                                
                                                     echo $historia->transaction_type_count;

                                                   }else{

                                                     echo '0';

                                                   }
                                            ?>
                                          </th>
                                          <th>
                                             <?php 
                                             $historia = DB::table('histories')
                                                   ->select(DB::raw('count(transaction_type_id) as transaction_type_count'))
                                                   ->where('item_id', '=', $history->item_id)
                                                   ->where('transaction_type_id','=', '5')
                                                   ->first(); 

                                              if (!empty($historia->transaction_type_count) AND isset($historia->transaction_type_count))
                                                   {
                                                
                                                     echo $historia->transaction_type_count;

                                                   }else{

                                                     echo '0';

                                                   }
                                            ?>
                                          </th>
                                          <th>
                                             <?php 
                                             $historia = DB::table('histories')
                                                   ->select(DB::raw('count(transaction_type_id) as transaction_type_count'))
                                                   ->where('item_id', '=', $history->item_id)
                                                   ->where('transaction_type_id','=', '15')
                                                   ->first(); 

                                              if (!empty($historia->transaction_type_count) AND isset($historia->transaction_type_count))
                                                   {
                                                
                                                     echo $historia->transaction_type_count;

                                                   }else{

                                                     echo '0';

                                                   }
                                            ?>
                                          </th>
                                          <th>
                                             <?php 
                                             $historia = DB::table('histories')
                                                   ->select(DB::raw('count(transaction_type_id) as transaction_type_count'))
                                                   ->where('item_id', '=', $history->item_id)
                                                   ->where('transaction_type_id','=', '16')
                                                   ->first(); 

                                              if (!empty($historia->transaction_type_count) AND isset($historia->transaction_type_count))
                                                   {
                                                
                                                     echo $historia->transaction_type_count;

                                                   }else{

                                                     echo '0';

                                                   }
                                            ?>
                                          </th>
                                          <th>
                                             <?php 
                                             $historia = DB::table('histories')
                                                   ->select(DB::raw('count(transaction_type_id) as transaction_type_count'))
                                                   ->where('item_id', '=', $history->item_id)
                                                   ->where('transaction_type_id','=', '17')
                                                   ->first(); 

                                              if (!empty($historia->transaction_type_count) AND isset($historia->transaction_type_count))
                                                   {
                                                
                                                     echo $historia->transaction_type_count;

                                                   }else{

                                                     echo '0';

                                                   }
                                            ?>
                                          </th>
                                          <th>
                                             <?php 
                                             $historia = DB::table('histories')
                                                   ->select(DB::raw('count(transaction_type_id) as transaction_type_count'))
                                                   ->where('item_id', '=', $history->item_id)
                                                   ->where('transaction_type_id','=', '19')
                                                   ->first(); 

                                              if (!empty($historia->transaction_type_count) AND isset($historia->transaction_type_count))
                                                   {
                                                
                                                     echo $historia->transaction_type_count;

                                                   }else{

                                                     echo '0';

                                                   }
                                            ?>
                                          </th>
                                          <th>
                                             <?php 
                                             $historia = DB::table('histories')
                                                   ->select(DB::raw('count(transaction_type_id) as transaction_type_count'))
                                                   ->where('item_id', '=', $history->item_id)
                                                   ->where('transaction_type_id','=', '21')
                                                   ->first(); 

                                              if (!empty($historia->transaction_type_count) AND isset($historia->transaction_type_count))
                                                   {
                                                
                                                     echo $historia->transaction_type_count;

                                                   }else{

                                                     echo '0';

                                                   }
                                            ?>
                                          </th> 


                                          <th>
                                             <?php 
                                             $historia = DB::table('histories')
                                                   ->select(DB::raw('count(transaction_type_id) as transaction_type_count'))
                                                   ->where('item_id', '=', $history->item_id)
                                                   ->where('transaction_type_id','=', '22')
                                                   ->first(); 

                                              if (!empty($historia->transaction_type_count) AND isset($historia->transaction_type_count))
                                                   {
                                                
                                                     echo $historia->transaction_type_count;

                                                   }else{

                                                     echo '0';

                                                   }
                                            ?>
                                          </th> 
                                          <th>
                                             <?php 
                                             $historia = DB::table('histories')
                                                   ->select(DB::raw('count(transaction_type_id) as transaction_type_count'))
                                                   ->where('item_id', '=', $history->item_id)
                                                   ->where('transaction_type_id','=', '23')
                                                   ->first(); 

                                              if (!empty($historia->transaction_type_count) AND isset($historia->transaction_type_count))
                                                   {
                                                
                                                     echo $historia->transaction_type_count;

                                                   }else{

                                                     echo '0';

                                                   }
                                            ?>
                                          </th> 
                                          <th>
                                             <?php 
                                             $historia = DB::table('histories')
                                                   ->select(DB::raw('count(transaction_type_id) as transaction_type_count'))
                                                   ->where('item_id', '=', $history->item_id)
                                                   ->where('transaction_type_id','=', '24')
                                                   ->first(); 

                                              if (!empty($historia->transaction_type_count) AND isset($historia->transaction_type_count))
                                                   {
                                                
                                                     echo $historia->transaction_type_count;

                                                   }else{

                                                     echo '0';

                                                   }
                                            ?>
                                          </th> 
                                          <th>
                                             <?php 
                                             $historia = DB::table('histories')
                                                   ->select(DB::raw('count(transaction_type_id) as transaction_type_count'))
                                                   ->where('item_id', '=', $history->item_id)
                                                   ->where('transaction_type_id','=', '25')
                                                   ->first(); 

                                              if (!empty($historia->transaction_type_count) AND isset($historia->transaction_type_count))
                                                   {
                                                
                                                     echo $historia->transaction_type_count;

                                                   }else{

                                                     echo '0';

                                                   }
                                            ?>
                                          </th> 
                                          <th>
                                             <?php 
                                             $historia = DB::table('histories')
                                                   ->select(DB::raw('count(transaction_type_id) as transaction_type_count'))
                                                   ->where('item_id', '=', $history->item_id)
                                                   ->where('transaction_type_id','=', '26')
                                                   ->first(); 

                                              if (!empty($historia->transaction_type_count) AND isset($historia->transaction_type_count))
                                                   {
                                                
                                                     echo $historia->transaction_type_count;

                                                   }else{

                                                     echo '0';

                                                   }
                                            ?>
                                          </th> 
                                          <th>
                                             <?php 
                                             $historia = DB::table('histories')
                                                   ->select(DB::raw('count(transaction_type_id) as transaction_type_count'))
                                                   ->where('item_id', '=', $history->item_id)
                                                   ->where('transaction_type_id','=', '27')
                                                   ->first(); 

                                              if (!empty($historia->transaction_type_count) AND isset($historia->transaction_type_count))
                                                   {
                                                
                                                     echo $historia->transaction_type_count;

                                                   }else{

                                                     echo '0';

                                                   }
                                            ?>
                                          </th> 



                                        </tr>                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    <?php /**PATH C:\Users\Jose Ortega\Desktop\formulario\resources\views/histories/partials/body.blade.php ENDPATH**/ ?>