<?php $__env->startSection('content'); ?>
    <div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="card">
                <div class="card-header">
                        Seccion de Muestra                
                </div>

                <div class="card-body">
                    <table class=" table table-striped table-sm display nowrap" id="history_table" style="width: 100%;">
                              <thead>
                                <tr>
                                    <th>ID</th> 
                                    <th>Código</th>
                                    <th>Descripción</th>                                     
                                  <?php $__currentLoopData = $transanction_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transanction_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th><?php echo e($transanction_type->name); ?></th>                                   
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                                </tr>
                              </thead>
                              <tbody>
                                    <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                          <th>1</th>
                                          <th>1</th>
                                          <th><?php echo e($history->item_id); ?></th>


                                          <th>1</th>
                                          <th>1</th>
                                          <th>1</th>
                                          <th>1</th>
                                          <th>1</th>
                                          <th>1</th>
                                          <th>1</th>
                                          <th>1</th>
                                          <th>1</th>
                                          <th>1</th>
                                          <th>1</th>
                                          <th>1</th>
                                          <th>1</th>
                                          <th>1</th>
                                          <th>1</th>
                                          <th>1</th>  

                                        </tr>                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                              </tbody>
                    </table>
                             
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\formulario\resources\views/histories/index.blade.php ENDPATH**/ ?>