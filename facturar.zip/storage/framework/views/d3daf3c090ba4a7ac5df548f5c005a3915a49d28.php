<?php $__env->startSection('content'); ?>
    <div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="card">
                <div class="card-header">
                        Seccion de Reportes                
                </div>

                <div class="card-body">
                    <table class="stripe row-border order-column" id="history_table" style="max-width: 100%;">
                              <thead>
                                <tr>
                                    <th>Código</th>
                                    <th>Descripción</th>
                                    <?php $__currentLoopData = $transanction_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transanction_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <th><?php echo e($transanction_type->name); ?></th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <th>Total de Transacciones</th>
                                   



                                </tr>
                              </thead>
                              <tbody>

                                 <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                              <th><?php echo e($history->mat_edtc); ?></th>
                                              <th><?php echo e($history->description); ?></th>
                                              <?php $sum_total = 0 ?>
                                              <?php $__currentLoopData = $transanction_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transanction_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                     <th>
                                                             <?php 
                                                            
                                                             $historia = DB::table('inv_material_transactions')
                                                                   ->select(DB::raw('count(transaction_type_id) as transaction_type_count'))
                                                                   ->where('item_id', '=', $history->item_id)
                                                                   ->where('transaction_type_id','=', $transanction_type->id)
                                                                   ->first(); 

                                                              if (!empty($historia->transaction_type_count) AND isset($historia->transaction_type_count))
                                                                   {
                                                                
                                                                     echo $historia->transaction_type_count;
                                                                     $sum_total+= $historia->transaction_type_count;

                                                                   }else{
                                                                     echo '0';
                                                                   }
                                                            ?>
                                                    </th>                                                     
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                              <th><?php echo e($sum_total); ?></th>

                                       </tr>                                        
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                    </table>
                             
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jose Ortega\Desktop\formulario\resources\views/histories/index.blade.php ENDPATH**/ ?>