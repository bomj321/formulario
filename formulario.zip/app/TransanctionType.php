<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TransanctionType extends Model
{
    //
}
