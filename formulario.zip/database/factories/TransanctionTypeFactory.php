<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\TransanctionType;
use Faker\Generator as Faker;

$factory->define(TransanctionType::class, function (Faker $faker) {
    return [
        //
    ];
});
