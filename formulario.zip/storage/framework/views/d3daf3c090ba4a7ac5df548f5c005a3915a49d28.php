<?php $__env->startSection('content'); ?>
    <div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="card">
                <div class="card-header">
                        Seccion de Reportes                
                </div>

                <div class="card-body">
                    <table class=" table table-striped table-sm display nowrap" id="history_table" style="width: 100%;">
                              <thead>
                                <tr>
                                    <th>Código</th>
                                    <th>Descripción</th>
                                    <th>A_INGRE_INV</th>                                   
                                    <th>E_DEVOLUCION CLIENTE</th>
                                    <th>F_PRESTAMO</th>
                                    <th>G_TRANSF</th>
                                    <th>H_DEVOLUION CAMPO_DESUSO</th>
                                    <th>I_BAJA</th>
                                    <th>B_INGRE COM</th>
                                    <th>C_SALIDA CAMPO</th>
                                    <th>D_DEVOLUCION CAMPO</th>


                                    <th>J_COMPRA DIRECTA</th>
                                    <th>K_PEDIDO MATERIAL</th>
                                    <th>L_APROBACION PEDIDO</th>
                                    <th>M_GUIA REMISION</th>
                                    <th>N_DESPACHO MATERIAL</th>
                                    <th>CSA_CORECC STOCK AUM</th>
                                    <th>CSD_CORRECC STOCK DISM</th>



                                </tr>
                              </thead>
                              <tbody>
                                   <?php echo $__env->make('histories.partials.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                              </tbody>
                    </table>
                             
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jose Ortega\Desktop\formulario\resources\views/histories/index.blade.php ENDPATH**/ ?>