$(document).ready( function () {
    $('#history_table').DataTable({
    	 responsive: true,
    	 "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Spanish.json"
        },

        dom: 'Bfrtip',
        buttons: [
            'excel'
        ]
    });
} );